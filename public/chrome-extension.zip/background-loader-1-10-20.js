// Loader versionado para forcar o Chrome a recarregar o service worker durante testes.
importScripts('background.js?v=1.10.20');
