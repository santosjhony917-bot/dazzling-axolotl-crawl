'use strict';
// Loader versionado para forçar o Chrome a recarregar o service worker durante testes.
importScripts('background.js?v=1.10.13');
